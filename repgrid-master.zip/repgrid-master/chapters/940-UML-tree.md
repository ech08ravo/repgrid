@startuml
object RepPlus #FFFFFF{
   Search Result 1 = 999
   Exclusion 1 = 999
 }
object epistemonikos {
   Search Result 1 = 999
   Exclusion 1 = 999
 }
object Cochrane_Library {
   Search Result 1 = 999
   Exclusion 1 = 999
 }
object APlus {
   Search Result 1 = 76
   Exclusion 1 = 27
 }
object ERIC {
   Search Result 1 = 199
   Exclusion 1 = 60
 }
object JSTOR {
   Search Result 1 = 999
   Exclusion 1 = 999
 }
object Web_of_Science {
   Search Result 1 = 999
   Exclusion 1 = 999
 }
object PSYCINFO {
   Search Result 1 = 999
   Exclusion 1 = 999
 }
object PROSPERO {
   Search Result 1 = 999
   Exclusion 1 = 999
 }
object Proquest {
   Search Result 1 = 999
   Exclusion 1 = 999
 }
object Scopus {
   Search Result 1 = 999
   Exclusion 1 = 999
 }
object Libraries_Australia {
   Search Result 1 = 999
   Exclusion 1 = 999
 }
object TRIP {
   Search Result 1 = 999
   Exclusion 1 = 999
 }

@enduml
