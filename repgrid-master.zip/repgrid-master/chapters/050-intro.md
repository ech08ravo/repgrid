I am finding it hard not to include papers that didn't address RepGrid but which made predictions or suggestions about computation or learning, and specifically artificial intelligence, that were insightful and useful and were written 40 years ago.


Consider why decision-making is an epistemic activity for the purpose of this thesis. Have to decide whether it's an epistemic, actional thing or dot. Argument needs to address:

Perkins Epistemic Games are restrictive from epistemic POV decision-making isn’t learning, not constructing knowledge.
How can decision-making provide epistemic values?

Professional Epistemic Games in epistemicfluency.com: EN & diff article p 409

Explain to reader, if I already know everything then decision-making is not a learning activity for me, how does the learning have clear value think of applied value, eg grad atrs, be explicit
How will this experiment generate value and not just be another lab experiment, at least know how you will write practical implications sections.
Decision-making is a series like gathering information or evaluating, it is an act, until you do that, you do a lot of learning, epistemic acts, movements,
How do you define decision making? Is it the inevitable outcome of that learning?
