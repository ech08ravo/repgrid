So I don't forget these wonderful moments.

Ling Wu, for patiently listening while I talked through my loosely formed ideas time and again.
Christine Tennent, for expert advice and sanity-checking my plans.
Peter, for being flexible enough to allow emergence
Lina, for being caring enough to ask for a backup of my work ;-)
The Library Staff, for their excellent Data Management workshop which made my life much more manageable.
