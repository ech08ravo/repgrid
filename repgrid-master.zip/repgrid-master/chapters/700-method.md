This is a self-explanation...
I have some data from surveys asking
x

I want to show two things in class.
One, is what the difference is between then and now - so I need to find:

1. what questions have I asked
1. where are the responses
1. which analytic method will I use.

based on spreadsheet
https://www.dropbox.com/s/gsrpa3ssr0tg83v/2019_S2_EDPC5024.xlsm?dl=0
the questions I have asked are:

A key thing to address is the format of rgid files and how they come across to either XML or excel.

The Rep5 Manual does provide details on format but not conversion or interoperability.

So I will download them all in rgrid and work on this as a problem to be solved.

### from "survey locations" tab 1444 on Sunday 3 November 2019.

step 1
which surveys did I use? go to spreadsheet, access each cache and download all grids into folder named with survey number.

done all dowloaded into folder by survey number, - summarised on https://www.dropbox.com/s/pvzayaw5cuhof5a/EDPC5024-survey-data-20191103.xlsx?dl=0
now I need to know which are relevant to the study and why

Two surveys had useful responses so far:
5024-0-3 [7] responses: 6 students, 1 teacher (one setup, two empty, test one demo and one student demo = 12 records)
5024-9-1 [3] responses, plus one duplicate and two testing
5024-9-2 [5 responses] no duplicates

two sets of responses were also received differently as they were not cached centrally but individually

5024-9-1 indiv [6 responses, one with no data]
5024-9-2 indiv [5 responses, potentially one duplicate]

[link to de-identified data in the Appendices ]

Week 13 to come (hopefully)
-- enough on surveys for now - back to Mildred
