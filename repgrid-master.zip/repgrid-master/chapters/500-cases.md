While {Bell, 1990 #118} is still buried in the Library somewhere, Harri-Augstein's other work provides a meaningful bridge between educational research and RepGrid. 
